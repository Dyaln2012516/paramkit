import{E as o}from"../chunks/ByqK_VNA.js";export{o as component};
